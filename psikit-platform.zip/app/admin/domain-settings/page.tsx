import { DomainSettings } from "@/components/domain-settings"

export default function DomainSettingsPage() {
  return <DomainSettings />
}
